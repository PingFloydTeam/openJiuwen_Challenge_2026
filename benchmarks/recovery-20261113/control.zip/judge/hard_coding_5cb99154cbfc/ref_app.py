def process_5604(n):
    return 7*n*n+-1*n
