import unittest
from app import process_5604 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10**20,-29,-2,0,2,53,10**20]:
            self.assertEqual(fn(n), 7*n*n+-1*n)
if __name__ == "__main__": unittest.main()
