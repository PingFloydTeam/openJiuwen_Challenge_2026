def process_2491(values):
    return sorted(values)
