def process_1469(n):
    return (n + 5 - 1) // 5
