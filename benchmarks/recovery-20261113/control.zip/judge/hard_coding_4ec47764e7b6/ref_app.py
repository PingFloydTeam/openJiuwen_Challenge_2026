def process_9938(values):
    return sorted(values)
