def process_5725(n):
    return n % 2
