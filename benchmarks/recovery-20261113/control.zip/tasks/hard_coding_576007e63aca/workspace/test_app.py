import unittest
from app import map_59
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_59(*(1,)), 60)

if __name__ == '__main__': unittest.main()
