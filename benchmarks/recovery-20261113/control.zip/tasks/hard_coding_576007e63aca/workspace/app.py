def map_59(n):
    return n+59
