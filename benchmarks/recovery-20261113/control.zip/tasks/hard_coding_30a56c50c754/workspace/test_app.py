import unittest
from app import map_44
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_44(*(1,)), 45)

if __name__ == '__main__': unittest.main()
