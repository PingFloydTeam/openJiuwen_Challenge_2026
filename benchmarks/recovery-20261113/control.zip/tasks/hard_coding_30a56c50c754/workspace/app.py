def map_44(n):
    return n+44
