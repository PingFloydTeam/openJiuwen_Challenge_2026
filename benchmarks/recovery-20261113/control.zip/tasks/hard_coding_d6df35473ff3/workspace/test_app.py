import unittest
from app import process_3612
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_3612(*([2, 1],)), [1, 2])

if __name__ == '__main__': unittest.main()
