def process_3612(values):
    return sorted(set(values))
