def process_5725(n):
    return abs(n) % 2
