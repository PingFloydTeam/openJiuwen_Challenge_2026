import unittest
from app import process_5604
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_5604(*(1,)), 6)

if __name__ == '__main__': unittest.main()
