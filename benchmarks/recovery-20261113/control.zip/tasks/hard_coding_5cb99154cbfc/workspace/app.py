def process_5604(n):
    return (7+-1)*n
