def process_1469(n):
    return int(n / 5) + int(n % 5 != 0)
