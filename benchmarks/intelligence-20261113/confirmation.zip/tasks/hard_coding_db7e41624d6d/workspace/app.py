def process_2377(n):
    return int(n / 5) + int(n % 5 != 0)
