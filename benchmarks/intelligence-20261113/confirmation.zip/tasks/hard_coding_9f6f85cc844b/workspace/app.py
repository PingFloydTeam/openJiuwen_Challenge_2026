def process_5360(n):
    return int(n / 6) + int(n % 6 != 0)
