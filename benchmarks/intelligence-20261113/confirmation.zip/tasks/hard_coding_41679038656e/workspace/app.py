def process_9679(n):
    return abs(n) % 5
