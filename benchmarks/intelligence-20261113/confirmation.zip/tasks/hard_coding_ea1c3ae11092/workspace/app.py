def process_1401(values):
    return sorted(set(values))
