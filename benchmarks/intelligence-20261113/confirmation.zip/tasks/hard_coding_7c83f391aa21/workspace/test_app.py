import unittest
from app import process_1096
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_1096(*([2, 1],)), [1, 2])

if __name__ == '__main__': unittest.main()
