import unittest
from app import map_42
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_42(*(1,)), 43)

if __name__ == '__main__': unittest.main()
