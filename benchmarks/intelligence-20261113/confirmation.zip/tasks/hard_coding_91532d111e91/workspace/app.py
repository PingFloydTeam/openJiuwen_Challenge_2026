def map_42(n):
    return n+42
