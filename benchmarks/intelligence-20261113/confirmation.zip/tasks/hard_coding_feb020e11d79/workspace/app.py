def process_2288(n):
    return (6+-1)*n
