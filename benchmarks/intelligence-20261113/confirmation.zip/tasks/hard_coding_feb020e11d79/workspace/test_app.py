import unittest
from app import process_2288
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_2288(*(1,)), 5)

if __name__ == '__main__': unittest.main()
