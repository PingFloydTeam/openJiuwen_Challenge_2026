import unittest
from app import map_48
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_48(*(1,)), 49)

if __name__ == '__main__': unittest.main()
