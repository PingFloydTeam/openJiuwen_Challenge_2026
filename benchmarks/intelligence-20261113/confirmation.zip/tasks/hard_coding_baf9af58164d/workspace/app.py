def map_48(n):
    return n+48
