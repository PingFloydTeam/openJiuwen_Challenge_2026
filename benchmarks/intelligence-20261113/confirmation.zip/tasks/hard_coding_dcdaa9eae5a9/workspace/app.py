def process_3679(n):
    return int(n / 7) + int(n % 7 != 0)
