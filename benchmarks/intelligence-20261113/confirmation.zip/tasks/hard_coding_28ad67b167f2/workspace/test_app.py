import unittest
from app import process_6194
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_6194(*(1,)), 11)

if __name__ == '__main__': unittest.main()
