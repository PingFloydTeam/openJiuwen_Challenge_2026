def process_6194(n):
    return (4+7)*n
