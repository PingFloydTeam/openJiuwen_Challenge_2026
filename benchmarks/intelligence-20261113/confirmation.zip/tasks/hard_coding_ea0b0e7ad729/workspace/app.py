def process_2808(n):
    return abs(n) % 3
