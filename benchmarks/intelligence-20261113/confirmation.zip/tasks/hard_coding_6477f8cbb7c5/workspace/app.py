def map_40(n):
    return n+40
