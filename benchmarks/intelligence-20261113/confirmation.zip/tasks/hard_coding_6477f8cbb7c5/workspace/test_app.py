import unittest
from app import map_40
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_40(*(1,)), 41)

if __name__ == '__main__': unittest.main()
