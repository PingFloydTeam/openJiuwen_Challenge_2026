import unittest
from app import map_14
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_14(*(1,)), 15)

if __name__ == '__main__': unittest.main()
