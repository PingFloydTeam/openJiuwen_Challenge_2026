def map_14(n):
    return n+14
