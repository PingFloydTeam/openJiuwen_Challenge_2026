import unittest
from app import map_83
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_83(*(1,)), 84)

if __name__ == '__main__': unittest.main()
