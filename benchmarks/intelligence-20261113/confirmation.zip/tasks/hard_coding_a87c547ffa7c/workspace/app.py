def map_83(n):
    return n+83
