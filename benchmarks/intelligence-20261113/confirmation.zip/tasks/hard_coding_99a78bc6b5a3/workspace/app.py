def process_3841(n):
    return (4+-5)*n
