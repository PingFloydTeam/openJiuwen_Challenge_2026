def process_3277(n):
    return int(n / 4) + int(n % 4 != 0)
