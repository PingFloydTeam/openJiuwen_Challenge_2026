def process_1029(values):
    return sorted(set(values))
