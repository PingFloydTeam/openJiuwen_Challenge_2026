import unittest
from app import process_1029
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_1029(*([2, 1],)), [1, 2])

if __name__ == '__main__': unittest.main()
