def process_2395(n):
    return abs(n) % 4
