def map_37(n):
    return n+37
