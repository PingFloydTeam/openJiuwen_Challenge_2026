import unittest
from app import map_37
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_37(*(1,)), 38)

if __name__ == '__main__': unittest.main()
