def process_3306(n):
    return int(n / 7) + int(n % 7 != 0)
