def process_5290(n):
    return abs(n) % 4
