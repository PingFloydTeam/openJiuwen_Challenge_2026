def process_1953(n):
    return abs(n) % 2
