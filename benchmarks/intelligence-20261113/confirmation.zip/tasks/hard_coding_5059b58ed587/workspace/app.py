def process_6544(values):
    return sorted(set(values))
