def process_3034(n):
    return (2+-1)*n
