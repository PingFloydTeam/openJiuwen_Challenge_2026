def process_2423(values):
    return sorted(values)
