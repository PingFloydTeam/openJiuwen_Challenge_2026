def process_1953(n):
    return n % 2
