import unittest
from app import process_5290 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10**40,-101,-4,-1,0,2,10**40]:
            self.assertEqual(fn(n), n % 4)
if __name__ == "__main__": unittest.main()
