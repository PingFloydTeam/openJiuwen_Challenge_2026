def process_5290(n):
    return n % 4
