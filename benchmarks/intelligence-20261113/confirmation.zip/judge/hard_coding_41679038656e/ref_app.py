def process_9679(n):
    return n % 5
