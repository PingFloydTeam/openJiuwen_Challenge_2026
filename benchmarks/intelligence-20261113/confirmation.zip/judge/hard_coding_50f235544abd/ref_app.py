def process_2395(n):
    return n % 4
