def process_3034(n):
    return 2*n*n+-1*n
