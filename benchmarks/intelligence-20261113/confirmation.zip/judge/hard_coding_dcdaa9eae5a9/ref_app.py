def process_3679(n):
    return (n + 7 - 1) // 7
