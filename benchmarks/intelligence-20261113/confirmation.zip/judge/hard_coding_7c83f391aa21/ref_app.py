def process_1096(values):
    return sorted(values)
