def process_5360(n):
    return (n + 6 - 1) // 6
