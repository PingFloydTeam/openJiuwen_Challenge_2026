def process_2808(n):
    return n % 3
