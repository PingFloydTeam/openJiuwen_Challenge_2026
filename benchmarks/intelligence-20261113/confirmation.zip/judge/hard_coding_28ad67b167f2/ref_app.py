def process_6194(n):
    return 4*n*n+7*n
