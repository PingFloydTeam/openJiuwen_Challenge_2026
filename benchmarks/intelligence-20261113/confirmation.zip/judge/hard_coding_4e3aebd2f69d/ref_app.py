def process_3277(n):
    return (n + 4 - 1) // 4
