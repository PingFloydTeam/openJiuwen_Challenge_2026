def process_2377(n):
    return (n + 5 - 1) // 5
