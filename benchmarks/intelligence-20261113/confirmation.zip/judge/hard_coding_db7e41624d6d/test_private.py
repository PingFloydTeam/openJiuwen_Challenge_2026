import unittest
from app import process_2377 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10**70-3,-19,-1,0,1,19,10**70+3]:
            self.assertEqual(fn(n), -((-n)//5))
if __name__ == "__main__": unittest.main()
