def process_3841(n):
    return 4*n*n+-5*n
