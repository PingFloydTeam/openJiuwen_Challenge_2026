def process_3306(n):
    return (n + 7 - 1) // 7
