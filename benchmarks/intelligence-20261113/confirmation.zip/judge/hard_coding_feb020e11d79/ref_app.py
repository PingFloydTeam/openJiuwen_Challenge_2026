def process_2288(n):
    return 6*n*n+-1*n
