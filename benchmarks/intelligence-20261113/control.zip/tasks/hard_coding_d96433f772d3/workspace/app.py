def process_1908(n):
    return abs(n) % 3
