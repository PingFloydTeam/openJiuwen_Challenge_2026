def process_6094(values):
    return sorted(set(values))
