import unittest
from app import process_6094
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_6094(*([2, 1],)), [1, 2])

if __name__ == '__main__': unittest.main()
