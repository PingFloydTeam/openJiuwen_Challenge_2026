def process_2976(values):
    return sorted(set(values))
