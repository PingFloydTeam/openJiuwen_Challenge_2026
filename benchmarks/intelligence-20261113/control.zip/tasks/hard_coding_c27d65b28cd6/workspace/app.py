def map_12(n):
    return n+12
