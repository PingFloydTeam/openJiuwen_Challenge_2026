import unittest
from app import map_12
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_12(*(1,)), 13)

if __name__ == '__main__': unittest.main()
