def map_45(n):
    return n+45
