import unittest
from app import map_45
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_45(*(1,)), 46)

if __name__ == '__main__': unittest.main()
