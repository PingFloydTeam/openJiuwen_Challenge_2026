def process_6093(n):
    return (2+1)*n
