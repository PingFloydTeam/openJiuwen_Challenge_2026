import unittest
from app import process_6093
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_6093(*(1,)), 3)

if __name__ == '__main__': unittest.main()
