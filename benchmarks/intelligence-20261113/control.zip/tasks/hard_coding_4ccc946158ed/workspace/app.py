def process_2563(n):
    return abs(n) % 2
