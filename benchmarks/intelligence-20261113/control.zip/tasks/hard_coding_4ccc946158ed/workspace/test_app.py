import unittest
from app import process_2563
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_2563(*(1,)), 1)

if __name__ == '__main__': unittest.main()
