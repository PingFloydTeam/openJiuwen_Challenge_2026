def process_9610(n):
    return abs(n) % 7
