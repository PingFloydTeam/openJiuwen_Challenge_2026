def process_7906(n):
    return (6+7)*n
