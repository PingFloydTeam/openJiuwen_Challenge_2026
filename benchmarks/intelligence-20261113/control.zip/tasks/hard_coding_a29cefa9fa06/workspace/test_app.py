import unittest
from app import process_7906
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_7906(*(1,)), 13)

if __name__ == '__main__': unittest.main()
