import unittest
from app import map_94
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_94(*(1,)), 95)

if __name__ == '__main__': unittest.main()
