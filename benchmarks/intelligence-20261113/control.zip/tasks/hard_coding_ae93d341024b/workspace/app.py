def map_94(n):
    return n+94
