def process_6824(n):
    return (6+-8)*n
