import unittest
from app import process_6824
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_6824(*(1,)), -2)

if __name__ == '__main__': unittest.main()
