def process_7666(n):
    return int(n / 4) + int(n % 4 != 0)
