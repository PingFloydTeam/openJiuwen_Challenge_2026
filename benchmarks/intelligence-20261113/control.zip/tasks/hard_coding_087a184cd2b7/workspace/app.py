def process_9239(n):
    return abs(n) % 6
