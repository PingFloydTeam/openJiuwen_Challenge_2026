import unittest
from app import map_95
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_95(*(1,)), 96)

if __name__ == '__main__': unittest.main()
