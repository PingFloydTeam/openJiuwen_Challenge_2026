def map_95(n):
    return n+95
