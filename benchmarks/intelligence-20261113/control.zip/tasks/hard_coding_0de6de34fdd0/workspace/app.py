def process_4070(n):
    return int(n / 2) + int(n % 2 != 0)
