def process_2334(n):
    return int(n / 4) + int(n % 4 != 0)
