def process_8170(n):
    return (4+-2)*n
