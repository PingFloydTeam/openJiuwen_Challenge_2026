def process_6168(values):
    return sorted(set(values))
