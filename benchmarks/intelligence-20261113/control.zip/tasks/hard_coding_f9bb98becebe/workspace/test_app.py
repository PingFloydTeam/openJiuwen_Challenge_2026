import unittest
from app import process_2005
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_2005(*(1,)), 1)

if __name__ == '__main__': unittest.main()
