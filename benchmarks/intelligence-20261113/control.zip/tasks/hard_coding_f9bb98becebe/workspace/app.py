def process_2005(n):
    return abs(n) % 5
