def map_33(n):
    return n+33
