import unittest
from app import map_33
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_33(*(1,)), 34)

if __name__ == '__main__': unittest.main()
