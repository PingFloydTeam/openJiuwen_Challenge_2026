import unittest
from app import process_1911
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_1911(*(1,)), 1)

if __name__ == '__main__': unittest.main()
