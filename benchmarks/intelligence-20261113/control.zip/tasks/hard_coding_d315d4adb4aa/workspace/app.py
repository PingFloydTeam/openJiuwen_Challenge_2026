def process_1911(n):
    return int(n / 5) + int(n % 5 != 0)
