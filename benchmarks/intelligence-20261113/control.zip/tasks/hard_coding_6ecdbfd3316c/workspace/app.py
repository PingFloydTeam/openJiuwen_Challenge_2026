def process_6263(n):
    return int(n / 3) + int(n % 3 != 0)
