def process_6824(n):
    return 6*n*n+-8*n
