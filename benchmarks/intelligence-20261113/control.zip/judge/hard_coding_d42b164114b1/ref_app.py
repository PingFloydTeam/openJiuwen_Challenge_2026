def process_4925(values):
    return sorted(values)
