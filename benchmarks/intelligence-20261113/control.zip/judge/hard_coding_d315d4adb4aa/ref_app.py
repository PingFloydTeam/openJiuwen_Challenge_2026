def process_1911(n):
    return (n + 5 - 1) // 5
