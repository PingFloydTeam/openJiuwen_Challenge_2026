def process_1908(n):
    return n % 3
