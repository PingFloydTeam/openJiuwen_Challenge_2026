def process_6263(n):
    return (n + 3 - 1) // 3
