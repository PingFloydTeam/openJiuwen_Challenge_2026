def process_9610(n):
    return n % 7
