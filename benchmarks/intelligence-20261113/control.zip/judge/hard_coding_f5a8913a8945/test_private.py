import unittest
from app import process_9610 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10**40,-101,-7,-1,0,2,10**40]:
            self.assertEqual(fn(n), n % 7)
if __name__ == "__main__": unittest.main()
