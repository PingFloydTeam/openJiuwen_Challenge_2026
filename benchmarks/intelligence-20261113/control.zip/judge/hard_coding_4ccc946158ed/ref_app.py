def process_2563(n):
    return n % 2
