def process_8170(n):
    return 4*n*n+-2*n
