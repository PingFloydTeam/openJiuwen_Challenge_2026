import unittest
from app import process_4326 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for xs in [[],[4,4,1],[-3,2,-3,0],[9]*17,list(range(47,-1,-1))]:
            original=list(xs)
            self.assertEqual(fn(xs), sorted(xs))
            self.assertEqual(xs,original)
            self.assertEqual(fn(iter(xs)), sorted(xs))
if __name__ == "__main__": unittest.main()
