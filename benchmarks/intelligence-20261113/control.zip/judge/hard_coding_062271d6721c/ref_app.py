def process_4326(values):
    return sorted(values)
