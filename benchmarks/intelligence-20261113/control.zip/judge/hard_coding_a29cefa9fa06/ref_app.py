def process_7906(n):
    return 6*n*n+7*n
