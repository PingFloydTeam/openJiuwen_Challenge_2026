def process_2005(n):
    return n % 5
