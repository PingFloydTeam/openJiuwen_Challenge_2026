def process_6093(n):
    return 2*n*n+1*n
