def process_9239(n):
    return n % 6
