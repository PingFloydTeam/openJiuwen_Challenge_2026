def process_4070(n):
    return (n + 2 - 1) // 2
