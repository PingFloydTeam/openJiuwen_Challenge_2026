def process_2334(n):
    return (n + 4 - 1) // 4
