def process_7666(n):
    return (n + 4 - 1) // 4
