def process_5774(n):
    return 3+1
