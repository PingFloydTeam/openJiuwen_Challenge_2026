import unittest
from app import process_6497
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_6497(*(1,)), 5)

if __name__ == '__main__': unittest.main()
