import unittest
from app import process_5121
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_5121(*(1,)), 7)

if __name__ == '__main__': unittest.main()
