def process_5121(n):
    return 6+1
