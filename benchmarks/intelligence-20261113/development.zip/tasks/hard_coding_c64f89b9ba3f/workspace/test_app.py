import unittest
from app import map_21
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_21(*(1,)), 22)

if __name__ == '__main__': unittest.main()
