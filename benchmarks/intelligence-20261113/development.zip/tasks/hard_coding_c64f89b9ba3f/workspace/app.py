def map_21(n):
    return n+21
