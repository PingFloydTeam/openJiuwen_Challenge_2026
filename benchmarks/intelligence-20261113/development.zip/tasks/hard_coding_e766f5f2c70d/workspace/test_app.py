import unittest
from app import process_4430
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_4430(*(1,)), -2)

if __name__ == '__main__': unittest.main()
