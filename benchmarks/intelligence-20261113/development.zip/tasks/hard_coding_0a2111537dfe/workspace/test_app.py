import unittest
from app import process_9800
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_9800(*(1,)), 11)

if __name__ == '__main__': unittest.main()
