import unittest
from app import process_4763
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_4763(*(1,)), 4)

if __name__ == '__main__': unittest.main()
