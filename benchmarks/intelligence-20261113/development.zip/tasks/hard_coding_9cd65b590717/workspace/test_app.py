import unittest
from app import map_97
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(map_97(*(1,)), 98)

if __name__ == '__main__': unittest.main()
