def map_97(n):
    return n+97
