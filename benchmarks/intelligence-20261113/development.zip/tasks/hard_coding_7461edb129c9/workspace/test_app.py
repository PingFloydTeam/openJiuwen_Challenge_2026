import unittest
from app import process_5410
class Checks(unittest.TestCase):
    def test_values(self):
        self.assertEqual(process_5410(*(1,)), 8)

if __name__ == '__main__': unittest.main()
