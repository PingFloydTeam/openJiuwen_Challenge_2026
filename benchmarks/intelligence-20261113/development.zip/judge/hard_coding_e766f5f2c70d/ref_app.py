def process_4430(n):
    return 5*n+-7
