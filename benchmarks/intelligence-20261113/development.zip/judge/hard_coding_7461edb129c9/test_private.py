import unittest
from app import process_5410 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10000000000000001,-73,-4,0,2,19,10000000000000001]:
            self.assertEqual(fn(n), n*n+7)
if __name__ == "__main__": unittest.main()
