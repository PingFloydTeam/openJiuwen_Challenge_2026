def process_5410(n):
    return n*n+7
