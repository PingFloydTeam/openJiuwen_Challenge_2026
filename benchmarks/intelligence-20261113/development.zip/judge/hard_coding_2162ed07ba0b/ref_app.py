def process_5774(n):
    return n*n+3
