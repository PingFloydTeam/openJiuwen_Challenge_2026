def process_4763(n):
    return n*n+3
