def process_8146(n):
    return 7*n+4
