def process_9800(n):
    return 7*n+4
