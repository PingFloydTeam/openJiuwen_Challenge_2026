def process_6497(n):
    return 5*n+0
