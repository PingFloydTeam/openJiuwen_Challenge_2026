import unittest
from app import process_6497 as fn
class Private(unittest.TestCase):
    def test_contract(self):
        for n in [-10000000000000001,-73,-4,0,2,19,10000000000000001]:
            self.assertEqual(fn(n), 5*n+0)
if __name__ == "__main__": unittest.main()
