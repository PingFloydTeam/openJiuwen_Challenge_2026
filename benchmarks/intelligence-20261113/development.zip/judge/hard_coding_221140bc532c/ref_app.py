def process_5121(n):
    return n*n+6
